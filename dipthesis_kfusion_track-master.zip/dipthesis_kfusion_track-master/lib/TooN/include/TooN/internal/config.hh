/* TooN/internal/config.hh.  Generated from config.hh.in by configure.  */
/* #undef TOON_USE_LAPACK */
