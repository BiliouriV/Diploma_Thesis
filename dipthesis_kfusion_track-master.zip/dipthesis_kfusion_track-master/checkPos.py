#!/usr/bin/python
# Copyright (c) 2014 University of Edinburgh, Imperial College, University of Manchester.
# Developed in the PAMELA project, EPSRC Programme Grant EP/K008730/1
#
# This code is licensed under the MIT License.

import sys
import re
import math
import numpy
from openpyxl import Workbook
from os import path

kfusion_log_regex  =      "([0-9]+[\s]*)\\t" 
kfusion_log_regex += 8 *  "([0-9.]+)\\t" 
kfusion_log_regex += 3 *  "([-0-9.]+)\\t" 
kfusion_log_regex +=      "([01])\s+([01])"

nuim_log_regex =      "([0-9]+)" 
nuim_log_regex += 7 * "\\s+([-0-9e.]+)\\s*" 

workbook = Workbook()
xls_filename = "benchmark.xlsx"
sheet = workbook.active
sheet.title = "benchmarks"
# frame timings
frames = {}
row = 2
column = 'A'
commit_id = "empty"
if len(sys.argv) > 2:
    sheet.cell(row=1,column=1).value=sys.argv[2]
    commit_id = sys.argv[2]

if path.exists('commit_sha.txt'):
    commitsha_file = open('commit_sha.txt','r')
    commit_sha = commitsha_file.read()
    commitsha_file.close()
    sheet.cell(row=1,column=2,value=commit_sha)
# open files

# if len(sys.argv) != 2 :
#     print "I need one parameter, the benchmark log file"# and the original scene camera position file."
#     exit (1)

# open benchmark log file first
print "Get KFusion output data." 
framesDropped = 0
validFrames = 0
lastFrame = -1
untracked = -4
kfusion_traj = []
fileref = open(sys.argv[1],'r')
data    = fileref.read()
fileref.close()
lines = data.split("\n") # remove head + first line
headers = lines[0].split("\t")
fulldata = {}
if len(headers) == 17 :
    if headers[16] == "" :
        del headers[16]
if len(headers) == 16:
    print "Version with startTS and endTS"
    kfusion_log_regex += 2 *  "\\t([0-9.]+)" 
if len(headers) != 16 and len(headers) != 14 :
    print "Wrong KFusion log  file. Expected 14 or 16 columns but found " + str(len(headers))

    exit(1)
for variable in  headers :
    fulldata[variable] = []

for line in lines[1:] :
    matching = re.match(kfusion_log_regex,line)
    if matching :
        dropped =  int( matching.group(1)) - lastFrame - 1
        if dropped>0:     		
    		framesDropped = framesDropped + dropped    		
    		for pad in range(0,dropped) :
    	         kfusion_traj.append( lastValid )     	            
    	frames[int(matching.group(1))] = {}
        frames[int(matching.group(1))]["tracked"] = int(matching.group(13))
        frames[int(matching.group(1))]["integrated"] = int(matching.group(14))
        frames[int(matching.group(1))]["startTS"] = float(matching.group(15))
        frames[int(matching.group(1))]["endTS"] = float(matching.group(16))
        frames[int(matching.group(1))]["stages"] = {}  
    
        kfusion_traj.append( (matching.group(10),matching.group(11),matching.group(12),matching.group(13),1 ) )
        lastValid = (matching.group(10),matching.group(11),matching.group(12),matching.group(13), 0)
        if int(matching.group(13)) == 0 :
            untracked = untracked+1
        validFrames = validFrames +1
        for elem_idx in  range(len(headers)) :
            fulldata[headers[elem_idx]].append(float(matching.group(elem_idx+1)))
            if "computation" in headers[elem_idx] or "X" in headers[elem_idx] or "Z" in headers[elem_idx] or "Y" in headers[elem_idx] or "frame" in headers[elem_idx]  or "tracked" in headers[elem_idx] or "integrated" in headers[elem_idx] or "startTS" in headers[elem_idx] or "endTS" in headers[elem_idx]:  
                continue
            head = headers[elem_idx].strip()
            frames[int(matching.group(1))]["stages"][head] = float(matching.group(elem_idx+1))
        lastFrame = int(matching.group(1))
    else :
        #print "Skip KFusion line : " + line
        break
# open benchmark log file first
nuim_traj = []
fileref = open('/home/scripts/livingRoom2.gt.freiburg','r')#sys.argv[2],'r')
data    = fileref.read()
fileref.close()
lines = data.split("\n") # remove head + first line
for line in lines :
    matching = re.match(nuim_log_regex,line)
    if matching :
        nuim_traj.append( (matching.group(2),matching.group(3),matching.group(4)) )
    else :
        #print "Skip nuim line : " + line
        break

working_position = min ( len(kfusion_traj) , len(nuim_traj) )
print "KFusion valid frames " + str(validFrames) + ",  dropped frames: " + str(framesDropped)
print "KFusion result        : " + str(len(kfusion_traj)) + " positions."
print "NUIM  result        : " + str(len(nuim_traj)) + " positions."
print "Working position is : " + str(working_position) 
print "Untracked frames: " +str(untracked)
nuim_traj=nuim_traj[0:working_position]
kfusion_traj=kfusion_traj[0:working_position]

# Printout to excel
cell = column + str(row)
sheet[cell] = "KFusion valid frames "
cell = (chr(ord(column) + 1)) + str(row)
sheet[cell] = validFrames
row = row + 1
cell = column + str(row)
sheet[cell] = "KFusion dropped frames "
cell = (chr(ord(column) + 1)) + str(row)
sheet[cell] = framesDropped
row = row + 1
cell = column + str(row)
sheet[cell] = "KFusion result: "
cell = (chr(ord(column) + 1)) + str(row)
sheet[cell] = len(kfusion_traj)
row = row + 1
cell = column + str(row)
sheet[cell] = "NUIM  result"
cell = (chr(ord(column) + 1)) + str(row)
sheet[cell] = len(nuim_traj)
row = row + 1
cell = column + str(row)
sheet[cell] = "Working position is :"
cell = (chr(ord(column) + 1)) + str(row)
sheet[cell] = working_position
row = row + 1
cell = column + str(row)
sheet[cell] = "Untracked frames:"
cell = (chr(ord(column) + 1)) + str(row)
sheet[cell] = untracked




print "Shift KFusion trajectory..."

first = nuim_traj[0]
fulldata["ATE"] = []
fulldata["ACT X - GOLDEN_X"] = []
fulldata["ACT Y - GOLDEN_Y"] = []
fulldata["ACT Z - GOLDEN_Z"] = []

fulldata["ABS(X - GOLDEN_X)"] = []
fulldata["ABS(Y - GOLDEN_Y)"] = []
fulldata["ABS(Z - GOLDEN_Z)"] = []

atex_sum = 0.0
atey_sum = 0.0
atez_sum = 0.0

#ATE_wrt_kfusion does not consider the ATE for frames which were dropped if we are running in non process-every-frame mode
fulldata["ATE_wrt_kfusion"] = []
distance_since_valid=0;
#print "Frame  speed(m/s)   dlv(m) ATE(m)   valid   tracked"
for p in range(working_position) :
    kfusion_traj[p] = (float(kfusion_traj[p][0]) + float(first[0]) , - (float(kfusion_traj[p][1]) + float(first[1]) ) , float(kfusion_traj[p][2]) + float(first[2]), int(kfusion_traj[p][3]),int(kfusion_traj[p][4]) )
    diff = (abs( kfusion_traj[p][0] - float(nuim_traj[p][0])) ,  abs( kfusion_traj[p][1] - float(nuim_traj[p][1] )) ,  abs( kfusion_traj[p][2] - float(nuim_traj[p][2] )) )
    ate=math.sqrt(sum(( diff[0] * diff[0],  diff[1] * diff[1],  diff[2] * diff[2])))
    atex_sum = kfusion_traj[p][0] - float(nuim_traj[p][0])
    atey_sum = kfusion_traj[p][1] - float(nuim_traj[p][1])
    atez_sum = kfusion_traj[p][2] - float(nuim_traj[p][2])
    # Keep ATE for each frame
    frames[p]["stages"]["ATE"] = ate
    # Golden Trajectory
    frames[p]["golden"] = {}
    frames[p]["golden"]['X'] = float(nuim_traj[p][0])
    frames[p]["golden"]['Y'] = float(nuim_traj[p][1])
    frames[p]["golden"]['Z'] = float(nuim_traj[p][2])
    # Kfusion trajectory
    frames[p]['kfusion'] = {}
    frames[p]["kfusion"]['X'] = float(kfusion_traj[p][0])
    frames[p]["kfusion"]['Y'] = float(kfusion_traj[p][1])
    frames[p]["kfusion"]['Z'] = float(kfusion_traj[p][2])
    if( p==1 ): 
        lastValid = nuim_traj[p]
    if 1 ==1 :  
        dx = float(nuim_traj[p][0]) - float(lastValid[0])
        dy = float(nuim_traj[p][1]) - float(lastValid[1]) 
        dz = float(nuim_traj[p][2]) - float(lastValid[2])
        distA = math.sqrt((dx*dx) + (dz*dz))
        dist = math.sqrt( (dy*dy) + (distA *distA))
        speed = dist/0.0333
        if (kfusion_traj[p][3]==0):
            tracked = "untracked"
        else:
            tracked = ""
        if (kfusion_traj[p][4]==0):
            valid = "dropped"
        else:
            valid = "-"
        distance_since_valid = distance_since_valid + dist
#        print "%4d %6.6f %6.6f %6.6f %10s %10s"% (p, speed, distance_since_valid, ate, valid, tracked )
        lastValid =  nuim_traj[p]
        if kfusion_traj[p][4]==1:
            distance_since_valid= 0

    if (kfusion_traj[p][4] == 1 ):
        fulldata["ATE_wrt_kfusion"].append(ate)        
    fulldata["ATE"].append(ate)
    fulldata["ACT X - GOLDEN_X"].append(atex_sum)
    fulldata["ACT Y - GOLDEN_Y"].append(atey_sum)
    fulldata["ACT Z - GOLDEN_Z"].append(atez_sum)
    fulldata["ABS(X - GOLDEN_X)"].append(abs(atex_sum))
    fulldata["ABS(Y - GOLDEN_Y)"].append(abs(atey_sum))
    fulldata["ABS(Z - GOLDEN_Z)"].append(abs(atez_sum))
                    
#print "The following are designed to enable easy macchine readability of key data" 
#print "MRkey:,logfile,ATE,computaion,dropped,untracked"
#print ("MRdata:,%s,%6.6f,%6.6f,%d,%d") % ( sys.argv[1], numpy.mean(fulldata["ATE"]), numpy.mean(fulldata["computation"]), framesDropped, untracked)

# Check if there is a synthesisreport
synthesis = {}
if (path.exists('kernel_util_synthed.rpt')):
    synthesis_utilization_file = open("kernel_util_synthed.rpt",'r')
    synthesis_data =  synthesis_utilization_file.read()
    synthesis_utilization_file.close()
    synthesis_lines = synthesis_data.split("\n")
    synthesis['LUT'] = float(synthesis_lines[25].split("|")[2].split("[")[1].split("]")[0].split("%")[0])
    synthesis['LUT'] += float(synthesis_lines[25].split("|")[3].split("[")[1].split("]")[0].split("%")[0])
    synthesis['FF'] = float(synthesis_lines[25].split("|")[4].split("[")[1].split("]")[0].split("%")[0])
    synthesis['BRAM'] = float(synthesis_lines[25].split("|")[5].split("[")[1].split("]")[0].split("%")[0]) 
    synthesis['DSP'] = float(synthesis_lines[25].split("|")[6].split("[")[1].split("]")[0].split("%")[0])

print "\nA detailed statistical analysis is provided."
print "Runtimes are in seconds and the absolute trajectory error (ATE) is in meters." 
print "The ATE measure accuracy, check this number to see how precise your computation is."
print "Acceptable values are in the range of few centimeters."

sheet_results = workbook.create_sheet("X_Y_Z calculations")
sheet_results['A1'] = "#frame"
sheet_results['B1'] = "X"
sheet_results['C1'] = "Y"
sheet_results['D1'] = "Z"
sheet_results['E1'] = "X - GOLD"
sheet_results['F1'] = "Y - GOLD"
sheet_results['G1'] = "Z - GOLD"

# Scale timings 
scale = 1000 # *1000 for ms

# Kernel timing
kernel_timings = {}
if path.exists('kernel_timings.log'):
    fileref = open('kernel_timings.log','r')
    data    = fileref.read()
    fileref.close()
    lines = data.split("\n") # remove head + first line
    #headers = lines[0].split("\t")
    kerneldata = {}
    kernel_timings_log_regex = "([0-9a-zA-Z]+)\\t"
    kernel_timings_log_regex += 2*"([0-9.]+)\\t" 
    kernel_timings_log_regex += "([0-9.]+)"

    sheet_kernels = workbook.create_sheet("kernels")
    
    localRow = 2
    for line in lines[0:] :
        matching = re.match(kernel_timings_log_regex,line)
        if matching :
            if(matching.group(1) not in kerneldata.keys()):
                kerneldata[matching.group(1)] = []
            data = {}
            data["startTS"] = float(matching.group(3))
            data["endTS"] = float(matching.group(4))
            data["duration"] = data["endTS"] - data["startTS"]
            kerneldata[matching.group(1)].append(data)
            # Append data to frame data
            for frame in frames:
                if frames[frame]["startTS"] <= data["startTS"] and frames[frame]["endTS"] >= data["endTS"]:
                    # it belongs to this frame
                    if "kernels" not in frames[frame].keys():
                        frames[frame]["kernels"] = {}
                    if matching.group(1) not in frames[frame]["kernels"].keys():
                        frames[frame]["kernels"][matching.group(1)] = []
                    frames[frame]["kernels"][matching.group(1)].append(data)
                    break
        else :
            break
    # Print out to EXCEL
    column = 1
    for kernel in kerneldata.keys():
        row = 1
        sheet_kernels.cell(row=row,column=column+1).value = kernel
        # write the 2 timestamps and one difference
        sheet_kernels.cell(row=row+1,column=column).value = "startTS"
        sheet_kernels.cell(row=row+1,column=column+1).value = "endTS"
        sheet_kernels.cell(row=row+1,column=column+2).value = "duration"
        row = row + 2
        for timestamp in kerneldata[kernel]:
            sheet_kernels.cell(row=row,column=column).value = timestamp["startTS"]
            sheet_kernels.cell(row=row,column=column+1).value = timestamp["endTS"]
            sheet_kernels.cell(row=row,column=column+2).value = timestamp["endTS"] - timestamp["startTS"]
            row += 1
        column += 3

    # Iterate each frame to calculate kernel timings
    for frame in frames:
        # Each kernel
        for kernel in frames[frame]["kernels"]:
            durations = []
            if kernel not in kernel_timings.keys():
                kernel_timings[kernel] = []
            for reading in frames[frame]["kernels"][kernel]:
                durations.append(reading['duration'])
            kernel_timings[kernel].append(sum(durations))
    # add mean times for each kernel
    row = 13
    column = 2
    for kernel in kernel_timings.keys():
        if('initVolumeKernel' in kernel):
            continue
        if "mm2meters" in kernel:
            sheet.cell(row=row,column=column).value = "mm2meters"
            sheet.cell(row=row+1,column=column).value = numpy.mean(kernel_timings[kernel]) * scale
        if "bilateral" in kernel:
            sheet.cell(row=row,column=column+1).value = "bilateral"
            sheet.cell(row=row+1,column=column+1).value = numpy.mean(kernel_timings[kernel])* scale
        if "halfSample" in kernel:
            sheet.cell(row=row,column=column+2).value = "halfSample"
            sheet.cell(row=row+1,column=column+2).value = numpy.mean(kernel_timings[kernel]) * scale
        if "depth2vertex" in kernel:
            sheet.cell(row=row,column=column+3).value = "depth2vertex"
            sheet.cell(row=row+1,column=column+3).value = numpy.mean(kernel_timings[kernel])* scale
        if "vertex2normal" in kernel:
            sheet.cell(row=row,column=column+4).value = "vertex2normal"
            sheet.cell(row=row+1,column=column+4).value = numpy.mean(kernel_timings[kernel])* scale
        if "track" in kernel:
            sheet.cell(row=row,column=column+5).value = "track"
            sheet.cell(row=row+1,column=column+5).value = numpy.mean(kernel_timings[kernel])* scale
        if "reduce" in kernel:
            sheet.cell(row=row,column=column+6).value = "reduce"
            sheet.cell(row=row+1,column=column+6).value = numpy.mean(kernel_timings[kernel])* scale
        if "update" in kernel:
            sheet.cell(row=row,column=column+7).value = "updatePose"
            sheet.cell(row=row+1,column=column+7).value = numpy.mean(kernel_timings[kernel])* scale
        if "integrate" in kernel:
            sheet.cell(row=row,column=column+8).value = "integrate"
            sheet.cell(row=row+1,column=column+8).value = numpy.mean(kernel_timings[kernel])* scale
        if "raycast" in kernel:
            sheet.cell(row=row,column=column+9).value = "raycast"
            sheet.cell(row=row+1,column=column+9).value = numpy.mean(kernel_timings[kernel])* scale
        if "Depth" in kernel:
            sheet.cell(row=row,column=column+10).value = "renderDepth"
            sheet.cell(row=row+1,column=column+10).value = numpy.mean(kernel_timings[kernel])* scale
        if "renderTrack" in kernel:
            sheet.cell(row=row,column=column+11).value = "renderTrack"
            sheet.cell(row=row+1,column=column+11).value = numpy.mean(kernel_timings[kernel])* scale
        if "renderVolume" in kernel:
            sheet.cell(row=row,column=column+12).value = "renderVolume"
            sheet.cell(row=row+1,column=column+12).value = numpy.mean(kernel_timings[kernel])* scale



row = 11
column = 1
sheet.cell(row=row,column=column+15).value = "untracked frames"
sheet.cell(row=row+1,column=column+15).value = untracked

# create chart sheet in addition
sheet_charts = workbook.create_sheet("charts")
sheet_charts.cell(row=1,column=1).value = "Stages"
sheet_charts.cell(row=2,column=1).value = "preprocessing"
sheet_charts.cell(row=3,column=1).value = "tracking"
sheet_charts.cell(row=4,column=1).value = "integration"
sheet_charts.cell(row=5,column=1).value = "raycasting"
sheet_charts.cell(row=6,column=1).value = "rendering"

sheet_charts.cell(row=1,column=2).value = "min"
sheet_charts.cell(row=1,column=3).value = "max"
sheet_charts.cell(row=1,column=4).value = "mean"
for variable in sorted(fulldata.keys()) :
    #if "X" in variable or "Z" in variable or "Y" in variable or "frame" in variable  or "tracked" in variable      or "integrated" in variable  :  
     #   continue

    if (framesDropped == 0)  and (str(variable) == "ATE_wrt_kfusion"):
        continue
		
    print "%20.20s" % str(variable),
    print "\tMin : %6.6f" % min(fulldata[variable]),
    print "\tMax : %0.6f"  % max(fulldata[variable]),
    print "\tMean : %0.6f" % numpy.mean(fulldata[variable]),
    print "\tTotal : %0.8f" % sum(fulldata[variable])

    if "acquisition" in variable:
        sheet.cell(row=row,column=column).value = "acquisition"
        sheet.cell(row=row+1,column=column).value = numpy.mean(fulldata[variable]) * scale
    if "preprocessing" in variable:
        sheet.cell(row=row,column=column+1).value = "preprocessing"
        sheet.cell(row=row+1,column=column+1).value = numpy.mean(fulldata[variable])* scale
        sheet.merge_cells(start_row=row+1,start_column=column+1,end_row=row+1,end_column=column+2)
        sheet_charts.cell(row=2,column=2).value = min(fulldata[variable]) * scale
        sheet_charts.cell(row=2,column=3).value = max(fulldata[variable]) * scale
        sheet_charts.cell(row=2,column=4).value = numpy.mean(fulldata[variable]) * scale
    if "tracking" in variable:
        sheet.cell(row=row,column=column+3).value = "tracking"
        sheet.cell(row=row+1,column=column+3).value = numpy.mean(fulldata[variable])* scale
        sheet.merge_cells(start_row=row+1,start_column=column+3,end_row=row+1,end_column=column+8)
        sheet_charts.cell(row=3,column=2).value = min(fulldata[variable]) * scale
        sheet_charts.cell(row=3,column=3).value = max(fulldata[variable]) * scale
        sheet_charts.cell(row=3,column=4).value = numpy.mean(fulldata[variable]) * scale
    if "integration" in variable:
        sheet.cell(row=row,column=column+9).value = "integration"
        sheet.cell(row=row+1,column=column+9).value = numpy.mean(fulldata[variable])* scale
        sheet_charts.cell(row=4,column=2).value = min(fulldata[variable]) * scale
        sheet_charts.cell(row=4,column=3).value = max(fulldata[variable]) * scale
        sheet_charts.cell(row=4,column=4).value = numpy.mean(fulldata[variable]) * scale
    if "raycasting" in variable:
        sheet.cell(row=row,column=column+10).value = "raycasting"
        sheet.cell(row=row+1,column=column+10).value = numpy.mean(fulldata[variable])* scale
        sheet_charts.cell(row=5,column=2).value = min(fulldata[variable]) * scale
        sheet_charts.cell(row=5,column=3).value = max(fulldata[variable]) * scale
        sheet_charts.cell(row=5,column=4).value = numpy.mean(fulldata[variable]) * scale
    # if "computation" in variable:
    #     sheet.cell(row=row,column=column+14).value = "computation"
    #     sheet.cell(row=row+1,column=column+14).value = numpy.mean(fulldata[variable])* scale
    if "rendering" in variable:
        sheet.cell(row=row,column=column+11).value = "rendering"
        sheet.cell(row=row+1,column=column+11).value = numpy.mean(fulldata[variable])* scale
        sheet.merge_cells(start_row=row+1,start_column=column+11,end_row=row+1,end_column=column+13)
        sheet_charts.cell(row=6,column=2).value = min(fulldata[variable]) * scale
        sheet_charts.cell(row=6,column=3).value = max(fulldata[variable]) * scale
        sheet_charts.cell(row=6,column=4).value = numpy.mean(fulldata[variable]) * scale
    if "total" in variable:
        sheet.cell(row=row,column=column+14).value = "total"
        sheet.cell(row=row+1,column=column+14).value = (numpy.mean(fulldata[variable])-numpy.mean(fulldata["rendering"]))* scale
    if "ATE" in variable:
        sheet.cell(row=row,column=column+16).value = "ATE TOTAL"
        sheet.cell(row=row+1,column=column+16).value = sum(fulldata[variable])
        sheet.cell(row=row,column=column+17).value = "ATE MIN"
        sheet.cell(row=row+1,column=column+17).value = min(fulldata[variable])
        sheet.cell(row=row,column=column+18).value = "ATE MAX"
        sheet.cell(row=row+1,column=column+18).value = max(fulldata[variable])
        sheet.cell(row=row,column=column+19).value = "ATE MEAN"
        sheet.cell(row=row+1,column=column+19).value = numpy.mean(fulldata[variable])

        sheet.cell(row=row,column=column+20).value = "BRAM"
        if len(synthesis) == 4:
            sheet.cell(row=row+1,column=column+20).value = synthesis["BRAM"]
        sheet.cell(row=row,column=column+21).value = "DSP"
        if len(synthesis) == 4:
            sheet.cell(row=row+1,column=column+21).value = synthesis["DSP"]
        sheet.cell(row=row,column=column+22).value = "FF"
        if len(synthesis) == 4:
            sheet.cell(row=row+1,column=column+22).value = synthesis["FF"]
        sheet.cell(row=row,column=column+23).value = "LUT"
        if len(synthesis) == 4:
            sheet.cell(row=row+1,column=column+23).value = synthesis["LUT"]

    # print to excel
    # if "X" in variable and not "GOLDEN_X" in variable:
    #     col = 'B'
    #     rowLocal = 2
    #     for frame in fulldata[variable]:
    #         cell = chr(ord(col)-1) + str(rowLocal)
    #         sheet_results[cell] = rowLocal-1
    #         cell = col + str(rowLocal)
    #         sheet_results[cell] = frame
    #         rowLocal = rowLocal + 1
    # if "Y" in variable and not "GOLDEN_Y" in variable:
    #     col = 'C'
    #     rowLocal = 2
    #     for frame in fulldata[variable]:
    #         cell = col + str(rowLocal)
    #         sheet_results[cell] = frame
    #         rowLocal = rowLocal + 1
    # if "Z" in variable and not "GOLDEN_Z" in variable:
    #     col = 'D'
    #     rowLocal = 2
    #     for frame in fulldata[variable]:
    #         cell = col + str(rowLocal)
    #         sheet_results[cell] = frame
    #         rowLocal = rowLocal + 1
    if "GOLDEN_X" in variable:
        col = 'E'
        rowLocal = 2
        for frame in fulldata[variable]:
            cell = col + str(rowLocal)
            sheet_results[cell] = frame
            rowLocal = rowLocal + 1
    if "GOLDEN_Y" in variable:
        col = 'F'
        rowLocal = 2
        for frame in fulldata[variable]:
            cell = col + str(rowLocal)
            sheet_results[cell] = frame
            rowLocal = rowLocal + 1
    if "GOLDEN_Z" in variable:
        col = 'G'
        rowLocal = 2
        for frame in fulldata[variable]:
            cell = col + str(rowLocal)
            sheet_results[cell] = frame
            rowLocal = rowLocal + 1

# Write golden x,y,z in excel

sheet_results['H1'] = "golden_x"
sheet_results['I1'] = "golden_y"
sheet_results['J1'] = "golden_z"
columnresults = 8
for frame,value in sorted(frames.iteritems()):
    sheet_results.cell(row=frame+2,column=1).value = frame
    if 'golden' in value:
        sheet_results.cell(row=frame+2,column=columnresults).value = value['golden']['X']
        sheet_results.cell(row=frame+2,column=columnresults+1).value = value['golden']['Y']
        sheet_results.cell(row=frame+2,column=columnresults+2).value = value['golden']['Z']
    else:
        sheet_results.cell(row=frame+2,column=columnresults).value = 0.0
        sheet_results.cell(row=frame+2,column=columnresults+1).value = 0.0
        sheet_results.cell(row=frame+2,column=columnresults+2).value = 0.0
    if 'kfusion' in value:
        sheet_results.cell(row=frame+2,column=2).value = value['kfusion']['X']
        sheet_results.cell(row=frame+2,column=3).value = value['kfusion']['Y']
        sheet_results.cell(row=frame+2,column=4).value = value['kfusion']['Z']
    else:
        sheet_results.cell(row=frame+2,column=2).value = 0.0
        sheet_results.cell(row=frame+2,column=3).value = 0.0
        sheet_results.cell(row=frame+2,column=4).value = 0.0

# Update  column to add power measurements
column = column + 24
sheet.cell(row=row-1, column=column).value = "CPU Power"
sheet.cell(row=row, column=column).value = "min"
sheet.cell(row=row, column=column+1).value = "max"
sheet.cell(row=row, column=column+2).value = "mean"

sheet.cell(row=row-1, column=column+3).value = "PL Power"
sheet.cell(row=row, column=column+3).value = "min"
sheet.cell(row=row, column=column+4).value = "max"
sheet.cell(row=row, column=column+5).value = "mean"

sheet.cell(row=row-1, column=column+6).value = "CPU Energy"
sheet.cell(row=row, column=column+6).value = "min"
sheet.cell(row=row, column=column+7).value = "max"
sheet.cell(row=row, column=column+8).value = "mean"

sheet.cell(row=row-1, column=column+9).value = "PL Energy"
sheet.cell(row=row, column=column+9).value = "min"
sheet.cell(row=row, column=column+10).value = "max"
sheet.cell(row=row, column=column+11).value = "mean"

sheet_power = workbook.create_sheet("power")

# Stages timing
sheet_stages = workbook.create_sheet("frames")
stages_row = 2
stages_column = {}
stages_column["acquisition"] = 2
stages_column["preprocessing"] = 3
stages_column["tracking"] = 4
stages_column["integration"]= 5
stages_column["raycasting"]= 6
stages_column["rendering"] = 7
stages_column["total"] = 8
stages_column["ATE"] = 9
stages_column["CPU_power"] = 10
stages_column["CPU_energy"] = 11
stages_column["PL_power"] = 12
stages_column["PL_energy"] = 13
stages_column["x"] = 14
stages_column["y"] = 15
stages_column["z"] = 16
stages_column["x_golden"] = 17
stages_column["y_golden"] = 18
stages_column["z_golden"] = 19

stages_column["reduceKernel"] = 20
stages_column["renderTrackKernel"] = 21
stages_column["trackKernel"] = 22
stages_column["vertex2normalKernel"] = 23
stages_column["updatePoseKernel"] = 24
stages_column["mm2metersKernel"] = 25
stages_column["bilateralFilterKernel"] = 26
stages_column["halfSampleRobustImageKernel"] = 27
stages_column["renderDepthKernel"] = 28
stages_column["depth2vertexKernel"] = 29
stages_column["renderVolumeKernel"] = 30
stages_column["raycastKernel"] = 31
stages_column["integrateKernel"] = 32

sheet_stages.cell(row=1,column=1).value = "frame"
sheet_stages.cell(row=1,column=2).value = "acquisition"
sheet_stages.cell(row=1,column=3).value = "preprocessing"
sheet_stages.cell(row=1,column=4).value = "tracking"
sheet_stages.cell(row=1,column=5).value = "integration"
sheet_stages.cell(row=1,column=6).value = "raycasting"
sheet_stages.cell(row=1,column=7).value = "rendering"
sheet_stages.cell(row=1,column=8).value = "total"
sheet_stages.cell(row=1,column=9).value = "ATE"
sheet_stages.cell(row=1,column=10).value = "cpu_power"
sheet_stages.cell(row=1,column=11).value = "cpu_energy"
sheet_stages.cell(row=1,column=12).value = "pl_power"
sheet_stages.cell(row=1,column=13).value = "pl_energy"
sheet_stages.cell(row=1,column=14).value = "x"
sheet_stages.cell(row=1,column=15).value = "y"
sheet_stages.cell(row=1,column=16).value = "z"
sheet_stages.cell(row=1,column=17).value = "x_golden"
sheet_stages.cell(row=1,column=18).value = "y_golden"
sheet_stages.cell(row=1,column=19).value = "z_golden"

sheet_stages.cell(row=1,column=stages_column["reduceKernel"]).value = "reduceKernel"
sheet_stages.cell(row=1,column=stages_column["renderTrackKernel"]).value = "renderTrackKernel"
sheet_stages.cell(row=1,column=stages_column["trackKernel"]).value = "trackKernel"
sheet_stages.cell(row=1,column=stages_column["vertex2normalKernel"]).value = "vertex2normalKernel"
sheet_stages.cell(row=1,column=stages_column["updatePoseKernel"]).value = "updatePoseKernel"
sheet_stages.cell(row=1,column=stages_column["mm2metersKernel"]).value = "mm2metersKernel"
sheet_stages.cell(row=1,column=stages_column["bilateralFilterKernel"]).value = "bilateralFilterKernel"
sheet_stages.cell(row=1,column=stages_column["halfSampleRobustImageKernel"]).value = "halfSampleRobustImageKernel"
sheet_stages.cell(row=1,column=stages_column["renderDepthKernel"]).value = "renderDepthKernel"
sheet_stages.cell(row=1,column=stages_column["depth2vertexKernel"]).value = "depth2vertexKernel"
sheet_stages.cell(row=1,column=stages_column["renderVolumeKernel"]).value = "renderVolumeKernel"
sheet_stages.cell(row=1,column=stages_column["raycastKernel"]).value = "raycastKernel"
sheet_stages.cell(row=1,column=stages_column["integrateKernel"]).value = "integrateKernel"

 # Iterate each frame to calculate kernel timings
for frame,value in sorted(frames.iteritems()):
    sheet_stages.cell(row=stages_row,column=1).value = frame
    # Each stage
    for stage in frames[frame]["stages"]:
        if stage in ["X\t", "Y\t", "Z\t","startTS","endTS"]:
            continue
        if "total" in stage:
            # remove rendering time
            sheet_stages.cell(row=stages_row,column=stages_column[stage]).value=frames[frame]["stages"][stage]-frames[frame]["stages"]["rendering"]
        else:
            sheet_stages.cell(row=stages_row,column=stages_column[stage]).value=frames[frame]["stages"][stage]
    # X,Y,Z
    if "golden" in frames[frame]:
        sheet_stages.cell(row=stages_row,column=stages_column["x"]).value=frames[frame]['golden']['X']
        sheet_stages.cell(row=stages_row,column=stages_column["y"]).value=frames[frame]['golden']['Y']
        sheet_stages.cell(row=stages_row,column=stages_column["z"]).value=frames[frame]['golden']['Z']
    else:
        sheet_stages.cell(row=stages_row,column=stages_column["x"]).value=0
        sheet_stages.cell(row=stages_row,column=stages_column["y"]).value=0
        sheet_stages.cell(row=stages_row,column=stages_column["z"]).value=0
    if "kfusion" in frames[frame]:
        sheet_stages.cell(row=stages_row,column=stages_column["x_golden"]).value=frames[frame]['kfusion']['X']
        sheet_stages.cell(row=stages_row,column=stages_column["y_golden"]).value=frames[frame]['kfusion']['Y']
        sheet_stages.cell(row=stages_row,column=stages_column["z_golden"]).value=frames[frame]['kfusion']['Z']
    else:
        sheet_stages.cell(row=stages_row,column=stages_column["x_golden"]).value=0
        sheet_stages.cell(row=stages_row,column=stages_column["y_golden"]).value=0
        sheet_stages.cell(row=stages_row,column=stages_column["z_golden"]).value=0

    # kernel timings
    # Iterate each frame to calculate kernel timings
    if "kernels" in frames[frame]:
        # Each kernel
        for kernel in frames[frame]["kernels"]:
            durations = []
            if kernel not in stages_column:
                continue
            for reading in frames[frame]["kernels"][kernel]:
                durations.append(reading['duration'])
            sheet_stages.cell(row=stages_row,column=stages_column[kernel]).value = sum(durations)       
            
            
    stages_row += 1


workbook.save(filename=xls_filename)

