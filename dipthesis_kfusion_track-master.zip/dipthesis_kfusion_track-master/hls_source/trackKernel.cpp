#define _HW_

#include <kernels.hpp>
#include <string.h>

#define BUF_SIZE 10240 //output_buf size 16rows*320pixelsx*2float4
extern "C"{
void trackKernel(float4* output, float4* inVertex,
		float4* inNormal, int inSize_x, int inSize_y, float4* refVertex,
		float4* refNormal, int refSize_x, int refSize_y, float* Ttrack_f,
		float* view_f, float dist_threshold,
		float normal_threshold) {


	#pragma HLS INTERFACE s_axilite port=return bundle=control

	//#pragma HLS INTERFACE m_axi port=result offset=slave bundle=result
	//#pragma HLS INTERFACE s_axilite port=result bundle=control

	#pragma HLS INTERFACE m_axi  port=output offset=slave bundle=output
	#pragma HLS INTERFACE s_axilite port=output bundle=control

	#pragma HLS INTERFACE m_axi  port=inVertex offset=slave bundle=inVertex
	#pragma HLS INTERFACE s_axilite port=inVertex bundle=control

	#pragma HLS INTERFACE m_axi  port=inNormal offset=slave bundle=inNormal
	#pragma HLS INTERFACE s_axilite port=inNormal bundle=control

	#pragma HLS INTERFACE m_axi  port=refVertex offset=slave bundle=refVertex
	#pragma HLS INTERFACE s_axilite port=refVertex bundle=control

	#pragma HLS INTERFACE m_axi  port=refNormal offset=slave bundle=refNormal
	#pragma HLS INTERFACE s_axilite port=refNormal bundle=control

	#pragma HLS INTERFACE m_axi  port=Ttrack_f offset=slave bundle=Ttrack_f
	#pragma HLS INTERFACE s_axilite port=Ttrack_f bundle=control

	#pragma HLS INTERFACE m_axi  port=view_f offset=slave bundle=view_f
	#pragma HLS INTERFACE s_axilite port=view_f bundle=control

	#pragma HLS INTERFACE s_axilite port=inSize_x bundle=control
	#pragma HLS INTERFACE s_axilite port=inSize_y bundle=control
	#pragma HLS INTERFACE s_axilite port=refSize_x bundle=control
	#pragma HLS INTERFACE s_axilite port=refSize_y bundle=control
	#pragma HLS INTERFACE s_axilite port=dist_threshold bundle=control
	#pragma HLS INTERFACE s_axilite port=normal_threshold bundle=control

	#pragma HLS DATA_PACK variable=output
	#pragma HLS DATA_PACK variable=inVertex
	#pragma HLS DATA_PACK variable=inNormal
	#pragma HLS DATA_PACK variable=refVertex
	#pragma HLS DATA_PACK variable=refNormal


	Matrix4 Ttrack;
	Matrix4 view;


	float4 output_buff[BUF_SIZE];
	#pragma ARRAY_PARTITION variable=output_buff cyclic factor=2 dim=1
	//#pragma HLS ARRAY_RESHAPE variable=output_buff block factor=7 dim=1

	float temp1[16];

	memcpy(temp1, Ttrack_f, 16*sizeof(float));
	float temp2[16];
	memcpy(temp2, view_f, 16*sizeof(float));
	#pragma HLS ARRAY_PARTITION variable=temp1 complete
	#pragma HLS ARRAY_PARTITION variable=temp2 complete



	COPY_LOOP: for (int i = 0; i < 4; i ++) {
		#pragma HLS PIPELINE II=1
		Ttrack.data[i].x = temp1[i*4];
		Ttrack.data[i].y = temp1[i*4 + 1];
		Ttrack.data[i].z = temp1[i*4 + 2];
		Ttrack.data[i].w = temp1[i*4 + 3];
		view.data[i].x = temp2[i*4];
		view.data[i].y = temp2[i*4 + 1];
		view.data[i].z = temp2[i*4 + 2];
		view.data[i].w = temp2[i*4 + 3];
	}
	unsigned int pixely, pixelx;

	for (int k=0; k < inSize_y/16; k++) {
#pragma HLS LOOP_TRIPCOUNT min=15 max=15 avg=15
		for (pixely = 0; pixely < 16; pixely++) {
			for (pixelx = 0; pixelx < inSize_x; pixelx++) {
#pragma HLS LOOP_TRIPCOUNT min=320 max=320 avg=320
			#pragma HLS PIPELINE II=1

				int calc = 16*k + pixely;
				int idx = pixelx + calc * refSize_x;
				//int index = pixely*ROW_SIZE + pixelx*7;
				int index = 2*pixelx + pixely*640;
		    	int tmp = pixelx + calc * inSize_x;
				float4 inNormal_temp = inNormal[tmp];

				if (inNormal_temp.x == KFUSION_INVALID) {
					output_buff[index].x = -1.0;
					continue;
				}

				float3 projectedVertex = Ttrack
						* make_float3(inVertex[tmp]);
				float3 projectedPos = view * projectedVertex;
				float2 projPixel = make_float2(
						projectedPos.x / projectedPos.z + 0.5f,
						projectedPos.y / projectedPos.z + 0.5f);
				if (projPixel.x < 0 || projPixel.x > refSize_x - 1
						|| projPixel.y < 0 || projPixel.y > refSize_y - 1) {
					output_buff[index].x  = -2.0;
					continue;
				}

				uint2 refPixel = make_uint2(projPixel.x, projPixel.y);
				int ref_calc = refPixel.x + refPixel.y * refSize_x;
				float3 refVertex_temp = make_float3(refVertex[ref_calc]);
				float length_res = length(refVertex_temp - projectedVertex);;


				float4 refNormal_temp =refNormal[ref_calc];
				float3 referenceNormal;
				referenceNormal.x = refNormal_temp.x;
				referenceNormal.y = refNormal_temp.y;
				referenceNormal.z = refNormal_temp.z;
				float fst_out = dot(referenceNormal, refVertex_temp - projectedVertex);
				float3 cross_res = cross(projectedVertex, referenceNormal);
				if (referenceNormal.x == KFUSION_INVALID) {
					output_buff[index].x = -3.0;
					continue;
				}

				float3 projectedNormal = rotate(Ttrack,
						inNormal_temp);

				if (length_res > dist_threshold) {
					output_buff[index].x = -4.0;
					continue;
				}


				if (dot(projectedNormal, referenceNormal) < normal_threshold) {
					output_buff[index].x = -5.0;
					continue;
				}

				output_buff[index].x = 1.0;
				output_buff[index].y = fst_out;

				output_buff[index].z = referenceNormal.x;
				output_buff[index].w = referenceNormal.y;
				output_buff[index + 1].x = referenceNormal.z;
				output_buff[index + 1].y = cross_res.x;
				output_buff[index + 1].z = cross_res.y;
				output_buff[index + 1].w = cross_res.z;

			}
		}
		int pos = k*BUF_SIZE;
	    memcpy(&output[pos], output_buff, BUF_SIZE*sizeof(float4));
	}

}
}

