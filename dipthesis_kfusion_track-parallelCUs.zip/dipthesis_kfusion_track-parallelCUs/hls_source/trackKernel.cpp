#define _HW_

#include <kernels.hpp>
#include <string.h>

#define ROW_SIZE 2240 //rowelements

extern "C"{
void trackKernel(int* result, float* output, float4* inVertex,
		float4* inNormal, int inSize_x, int inSize_y, float4* refVertex,
		float4* refNormal, int refSize_x, int refSize_y, float* Ttrack_f,
		float* view_f, float dist_threshold,
		float normal_threshold, int cu_idx) {


	#pragma HLS INTERFACE s_axilite port=return bundle=control

	#pragma HLS INTERFACE m_axi port=result offset=slave bundle=result
	#pragma HLS INTERFACE s_axilite port=result bundle=control

	#pragma HLS INTERFACE m_axi  port=output offset=slave bundle=output
	#pragma HLS INTERFACE s_axilite port=output bundle=control

	#pragma HLS INTERFACE m_axi  port=inVertex offset=slave bundle=inVertex
	#pragma HLS INTERFACE s_axilite port=inVertex bundle=control

	#pragma HLS INTERFACE m_axi  port=inNormal offset=slave bundle=inNormal
	#pragma HLS INTERFACE s_axilite port=inNormal bundle=control

	#pragma HLS INTERFACE m_axi  port=refVertex offset=slave bundle=refVertex
	#pragma HLS INTERFACE s_axilite port=refVertex bundle=control

	#pragma HLS INTERFACE m_axi  port=refNormal offset=slave bundle=refNormal
	#pragma HLS INTERFACE s_axilite port=refNormal bundle=control

	#pragma HLS INTERFACE m_axi  port=Ttrack_f offset=slave bundle=Ttrack_f
	#pragma HLS INTERFACE s_axilite port=Ttrack_f bundle=control

	#pragma HLS INTERFACE m_axi  port=view_f offset=slave bundle=view_f
	#pragma HLS INTERFACE s_axilite port=view_f bundle=control

	#pragma HLS INTERFACE s_axilite port=inSize_x bundle=control
	#pragma HLS INTERFACE s_axilite port=inSize_y bundle=control
	#pragma HLS INTERFACE s_axilite port=refSize_x bundle=control
	#pragma HLS INTERFACE s_axilite port=refSize_y bundle=control
	#pragma HLS INTERFACE s_axilite port=dist_threshold bundle=control
	#pragma HLS INTERFACE s_axilite port=normal_threshold bundle=control
	#pragma HLS INTERFACE s_axilite port=cu_idx bundle=control

	#pragma HLS DATA_PACK variable=inVertex
	#pragma HLS DATA_PACK variable=inNormal
	#pragma HLS DATA_PACK variable=refVertex
	#pragma HLS DATA_PACK variable=refNormal


	Matrix4 Ttrack;
	Matrix4 view;


	float output_buff[ROW_SIZE];
	#pragma HLS ARRAY_PARTITION variable=output_buff cyclic factor=7 dim=1

	float temp1[16];
	memcpy(temp1, Ttrack_f, 16*sizeof(float));
	float temp2[16];
	memcpy(temp2, view_f, 16*sizeof(float));
	#pragma HLS ARRAY_PARTITION variable=temp1 complete
	#pragma HLS ARRAY_PARTITION variable=temp2 complete



	COPY_LOOP: for (int i = 0; i < 4; i ++) {
		#pragma HLS PIPELINE II=1
		Ttrack.data[i].x = temp1[i*4];
		Ttrack.data[i].y = temp1[i*4 + 1];
		Ttrack.data[i].z = temp1[i*4 + 2];
		Ttrack.data[i].w = temp1[i*4 + 3];
		view.data[i].x = temp2[i*4];
		view.data[i].y = temp2[i*4 + 1];
		view.data[i].z = temp2[i*4 + 2];
		view.data[i].w = temp2[i*4 + 3];
	}
	//uint2 pixel = make_uint2(0, 0);
	unsigned int pixely, pixelx;
	int quarter_size = inSize_y/4;
	int position = cu_idx*quarter_size;
	for (pixely = 0; pixely < quarter_size; pixely++) {
		for (pixelx = 0; pixelx < inSize_x; pixelx++) {
		#pragma HLS PIPELINE II=1
			//#pragma HLS DEPENDENCE variable=cross_resx inter false

			//pixel.x = pixelx;
			//pixel.y = pixely;

			//TrackData & row = output[pixel.x + pixel.y * refSize_x];
			int idx = pixelx + pixely * refSize_x;
			int index = pixelx*7;


			int tmp = pixelx + (pixely + position) * inSize_x;
			float4 inNormal_temp = inNormal[tmp];

			if (inNormal_temp.x == KFUSION_INVALID) {
				result[idx] = -1;
				continue;
			}

			float3 projectedVertex = Ttrack
					* make_float3(inVertex[tmp]);
			float3 projectedPos = view * projectedVertex;
			float2 projPixel = make_float2(
					projectedPos.x / projectedPos.z + 0.5f,
					projectedPos.y / projectedPos.z + 0.5f);
			if (projPixel.x < 0 || projPixel.x > refSize_x - 1
					|| projPixel.y < 0 || projPixel.y > refSize_y - 1) {
				result[idx] = -2;
				continue;
			}

			uint2 refPixel = make_uint2(projPixel.x, projPixel.y);
			int ref_calc = refPixel.x + refPixel.y * refSize_x;
			float3 refVertex_temp = make_float3(refVertex[ref_calc]);
			float length_res = length(refVertex_temp - projectedVertex);;


			float4 refNormal_temp =refNormal[ref_calc];
			float3 referenceNormal;
			referenceNormal.x = refNormal_temp.x;
			referenceNormal.y = refNormal_temp.y;
			referenceNormal.z = refNormal_temp.z;
			float fst_out = dot(referenceNormal, refVertex_temp - projectedVertex);
			float3 cross_res = cross(projectedVertex, referenceNormal);
			if (referenceNormal.x == KFUSION_INVALID) {
				result[idx] = -3;
				continue;
			}
			//test
			//float diffx = refVertex[ref_calc].x - projectedVertex.x;
			//float diffy = refVertex[ref_calc].y - projectedVertex.y;
			//float diffz = refVertex[ref_calc].z - projectedVertex.z;

			float3 projectedNormal = rotate(Ttrack,
				inNormal_temp);

			if (length_res > dist_threshold) {
				result[idx] = -4;
				continue;
			}


			if (dot(projectedNormal, referenceNormal) < normal_threshold) {
				result[idx] = -5;
				continue;
			}


			//idx *= 7;

			output_buff[index] = fst_out;
			//output_buff[index] = referenceNormal.x * diffx + referenceNormal.y * diffy + referenceNormal.z * diffz;

			//test
			/*float3 cross_res;

			cross_res.x = projectedVertex.y * referenceNormal.z - projectedVertex.z * referenceNormal.y;
			cross_res.y = projectedVertex.z * referenceNormal.x - projectedVertex.x * referenceNormal.z;
			/cross_res.x = projectedVertex.x * referenceNormal.y - projectedVertex.y * referenceNormal.x;*/

			output_buff[index + 1] = referenceNormal.x;
			output_buff[index + 2] = referenceNormal.y;
			output_buff[index + 3] = referenceNormal.z;
			output_buff[index + 4] = cross_res.x;
			output_buff[index + 5] = cross_res.y;
			output_buff[index + 6] = cross_res.z;
			result[idx] = 1;
		}

		int size = pixely*ROW_SIZE;
		memcpy(&output[size], output_buff, ROW_SIZE*sizeof(float));
	}

}
}
